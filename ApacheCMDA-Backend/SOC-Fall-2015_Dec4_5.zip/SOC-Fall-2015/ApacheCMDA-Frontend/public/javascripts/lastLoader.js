$(document).ready(function() 
    { 
        $("#myTable").tablesorter(); 
        $("#myTable2").tablesorter(); 
        $("#myTable3").tablesorter();
        $("#csTable").tablesorter(); 
    } 
); 